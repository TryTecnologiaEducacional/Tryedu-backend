<?php
class JourneysCategories extends Tabela {
  protected $tabela = 'JourneysCategories';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id', 'CategoryName','Description', 'idJourney', 'DateRelease');
  protected $legendas = array(
                             );

}
?>