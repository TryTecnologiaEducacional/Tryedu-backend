<?php
class HistoryEpisodes extends Tabela {
  protected $tabela = 'HistoryEpisodes';
  protected $chavePrimaria = 'id';
  protected $legendas = array(
                             );

}
?>