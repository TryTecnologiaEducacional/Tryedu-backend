<?php
class Schools extends Tabela {
  protected $tabela = 'Schools';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','SchoolName', 'SchoolCode','City','Provincy');
  protected $legendas = array();
    
}
?>