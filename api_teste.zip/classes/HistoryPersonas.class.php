<?php
class HistoryPersonas extends Tabela {
  protected $tabela = 'HistoryPersonas';
  protected $chavePrimaria = 'id';
  protected $legendas = array(
                             );

}
?>