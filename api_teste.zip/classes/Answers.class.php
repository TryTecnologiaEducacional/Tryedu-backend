<?php
class Answers extends Tabela {
  protected $tabela = 'Answers';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','idUser', 'idQuestions', 'AnswerErrors','AnswerTitle','AnswerDate','AnswerTime','ResponseTime', 'Answer');

}
?>