<?php
class HistoryDialogues extends Tabela {
  protected $tabela = 'HistoryDialogues';
  protected $chavePrimaria = 'id';
  protected $legendas = array(
                             );

}
?>