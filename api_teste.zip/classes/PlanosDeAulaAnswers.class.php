<?php
class PlanosDeAulaAnswers extends Tabela {
  protected $tabela = 'PlanosDeAulaAnswers';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','Name','Description','LinkPDF','LinkVideo', 'DateRelease', 'idCategorias');
  protected $legendas = array(
                             );

}
?>