<?php
class HistoryDialoguesAnswers extends Tabela {
  protected $tabela = 'HistoryDialoguesAnswers';
  protected $chavePrimaria = 'id';
  protected $legendas = array(
                             );

}
?>