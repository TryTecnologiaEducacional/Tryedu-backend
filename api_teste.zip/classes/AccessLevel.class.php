<?php
class AccessLevel extends Tabela {
  protected $tabela = 'AccessLevel';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','AccessName', 'AccessTitle', 'AccessRole');
  protected $legendas = array();

}
?>