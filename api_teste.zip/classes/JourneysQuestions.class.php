<?php
class JourneysQuestions extends Tabela {
  protected $tabela = 'JourneysQuestions';
  protected $chavePrimaria = 'id';
  protected $legendas = array(
                             );

}
?>