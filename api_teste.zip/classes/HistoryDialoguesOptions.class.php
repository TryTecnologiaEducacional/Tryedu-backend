<?php
class HistoryDialoguesOptions extends Tabela {
  protected $tabela = 'HistoryDialoguesOptions';
  protected $chavePrimaria = 'id';
  protected $legendas = array(
                             );

}
?>