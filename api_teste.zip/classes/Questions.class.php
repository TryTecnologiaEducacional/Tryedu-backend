<?php
class Questions extends Tabela {
  protected $tabela = 'Questions';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','ClassCode','QuestionName', 'Errors', 'Time','LevelDificult','Xp','QuestionTitle','QuestionBody','Answers','Category','MinScore','MaxScore','DateRelease', 'idAdventure', 'UrlImage');
  protected $legendas = array(
                             );

}
?>