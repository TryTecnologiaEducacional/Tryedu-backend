<?php
class HistoryStatus extends Tabela {
  protected $tabela = 'HistoryStatus';
  protected $chavePrimaria = 'id';
  protected $legendas = array(
                             );

}
?>