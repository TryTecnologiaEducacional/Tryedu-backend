<?php
class Adventure extends Tabela {
  protected $tabela = 'Adventure';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','Name','Description');
  protected $legendas = array(
                              'id' => 'id',
                             );
														 
}
?>