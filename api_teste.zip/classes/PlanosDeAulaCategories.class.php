<?php
class PlanosDeAulaCategories extends Tabela {
  protected $tabela = 'PlanosDeAulaCategories';
  protected $chavePrimaria = 'id';
  //protected $campos = $this->listarCampos();
  protected $legendas = array(
                             );

}
?>