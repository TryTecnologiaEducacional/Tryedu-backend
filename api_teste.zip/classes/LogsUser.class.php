<?php
class LogsUser extends Tabela {
  protected $tabela = 'LogsUser';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','idUser', 'DateLogin', 'DateLogout');
  protected $legendas = array(
                             );

}
?>