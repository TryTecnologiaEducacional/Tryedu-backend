<?php
class Classt extends Tabela {
  protected $tabela = 'Classt';
  protected $chavePrimaria = 'ClassCode';
  //protected $campos = array('ClassCode','ClassName','idTeacher');
  protected $legendas = array();

}
?>