<?php
class PlanosDeAulaQuestions extends Tabela {
  protected $tabela = 'PlanosDeAulaQuestions';
  protected $chavePrimaria = 'id';

}
?>