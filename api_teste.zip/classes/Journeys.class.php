<?php
class Journeys extends Tabela {
  protected $tabela = 'Journeys';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','JourneyName','Description');
  protected $legendas = array(
                             );

}
?>