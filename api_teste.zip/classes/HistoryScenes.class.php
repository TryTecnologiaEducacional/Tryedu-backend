<?php
class HistoryScenes extends Tabela {
  protected $tabela = 'HistoryScenes';
  protected $chavePrimaria = 'id';
  protected $legendas = array(
                             );

}
?>