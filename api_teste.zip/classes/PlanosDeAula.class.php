<?php
class PlanosDeAula extends Tabela {
  protected $tabela = 'PlanosDeAula';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','Name','Description','LinkPDF','LinkVideo', 'DateRelease', 'idCategorias');
  protected $legendas = array(
                             );

}
?>