<?php
class Dialog extends Tabela {
  protected $tabela = 'Dialog';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','DialogName', 'Title', 'Body','Answers','Language');
  protected $legendas = array(
                             );

}
?>