<?php
class JourneysAnswers extends Tabela {
  protected $tabela = 'JourneysAnswers';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','idUser', 'idQuestions', 'AnswerErrors','AnswerTitle','AnswerDate','AnswerTime','ResponseTime', 'Answer');
  
}
?>