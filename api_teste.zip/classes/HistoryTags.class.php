<?php
class HistoryTags extends Tabela {
  protected $tabela = 'HistoryTags';
  protected $chavePrimaria = 'id';
  protected $legendas = array(
                             );

}
?>