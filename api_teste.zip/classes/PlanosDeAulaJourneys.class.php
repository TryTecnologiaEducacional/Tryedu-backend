<?php
class PlanosDeAulaJourneys extends Tabela {
  protected $tabela = 'PlanosDeAulaJourneys';
  protected $chavePrimaria = 'id';

}
?>