<?php
class QuestionsClass extends Tabela {
  protected $tabela = 'QuestionsClass';
  protected $chavePrimaria = 'id';
  //protected $campos = array('id','idClass', 'idQuestions');
  protected $legendas = array(
                             );

}
?>