import * as React from 'react';

function IconSetaDireita(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      width={18}
      height={18}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M17.13 7.94l-6.714-7A1.4 1.4 0 009.023.555c-.496.14-.884.546-1.016 1.065a1.547 1.547 0 00.376 1.45l4.249 4.42H1.689C.895 7.49.25 8.162.25 8.99s.645 1.5 1.439 1.5h10.943l-4.249 4.42a1.547 1.547 0 00-.311 1.634c.222.56.746.925 1.328.926a1.394 1.394 0 001.016-.47l6.714-7a1.546 1.546 0 000-2.12v.06z"
        fill="#fff"
      />
    </svg>
  );
}

export default IconSetaDireita;
