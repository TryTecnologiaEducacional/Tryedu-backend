import * as React from 'react';

export function Play(props?: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      width="19"
      height="22"
      viewBox="0 0 19 22"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M2.34448 21.2404C2.83228 21.2404 3.262 21.0662 3.79625 20.7526L17.5125 12.8202C18.5113 12.2395 18.9294 11.7865 18.9294 11.0548C18.9294 10.3232 18.5113 9.88182 17.5125 9.2895L3.79625 1.35706C3.262 1.04347 2.83228 0.869263 2.34448 0.869263C1.39212 0.869263 0.718506 1.60095 0.718506 2.75075V19.3589C0.718506 20.5203 1.39212 21.2404 2.34448 21.2404Z"
        fill="white"
      />
    </svg>
  );
}

export default Play;
