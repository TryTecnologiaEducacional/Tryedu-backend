import * as React from 'react';

function IconeConfirm(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      width={15}
      height={15}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M7.5 0a7.5 7.5 0 100 15 7.5 7.5 0 000-15zM6.124 11.353L2.822 8.05l1.1-1.1 2.202 2.2 4.954-4.953 1.1 1.101-6.054 6.055z"
        fill="#0B6BCC"
      />
    </svg>
  );
}

export default IconeConfirm;
