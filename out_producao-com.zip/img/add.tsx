import * as React from 'react';

export function Add(props?: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      width="50"
      height="50"
      viewBox="0 0 50 50"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="25" cy="25" r="24.5" fill="white" stroke="black" />
      <path d="M32 26H26V32H24V26H18V24H24V18H26V24H32V26Z" fill="#191D21" />
    </svg>
  );
}

export default Add;
