import * as React from 'react';

function IconeGoogle(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      width={18}
      height={15}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <g clipPath="url(#prefix__clip0_764_9567)">
        <path
          d="M17.441 7.673c0-.51-.046-1.023-.144-1.524H9.4v2.888h4.522c-.188.931-.79 1.755-1.674 2.279v1.874h2.698c1.585-1.306 2.495-3.235 2.495-5.517z"
          fill="#4285F4"
        />
        <path
          d="M9.4 15c2.258 0 4.162-.664 5.55-1.81l-2.698-1.874c-.751.457-1.72.716-2.85.716-2.183 0-4.035-1.32-4.7-3.094H1.918v1.931c1.422 2.533 4.316 4.132 7.482 4.132z"
          fill="#34A853"
        />
        <path
          d="M4.7 8.938a4.05 4.05 0 010-2.872V4.134H1.917a6.812 6.812 0 000 6.736L4.7 8.938z"
          fill="#FBBC04"
        />
        <path
          d="M9.4 2.969c1.193-.017 2.347.385 3.211 1.124l2.39-2.141C13.489.678 11.48-.022 9.4 0 6.234 0 3.34 1.599 1.918 4.134L4.7 6.066C5.361 4.29 7.216 2.97 9.4 2.97z"
          fill="#EA4335"
        />
      </g>
      <defs>
        <clipPath id="prefix__clip0_764_9567">
          <path fill="#fff" transform="translate(.86)" d="M0 0h16.744v15H0z" />
        </clipPath>
      </defs>
    </svg>
  );
}

export default IconeGoogle;
