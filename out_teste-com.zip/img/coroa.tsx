import * as React from 'react';

export function IconCoroa(props?: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      width="43"
      height="47"
      viewBox="0 0 43 47"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g filter="url(#filter0_d_56:1162)">
        <g filter="url(#filter1_di_56:1162)">
          <path
            d="M20.6825 37.0731L17.4442 29.0533C17.2461 28.5627 17.3034 27.9524 17.5856 27.5467L20.8239 22.8914C21.192 22.3622 21.8076 22.3622 22.1756 22.8914L25.4139 27.5467C25.6961 27.9524 25.7534 28.5627 25.5553 29.0533L22.317 37.0731C21.9613 37.954 21.0382 37.954 20.6825 37.0731Z"
            fill="#FFF8DE"
          />
        </g>
        <path
          d="M8.97021 36.4244C8.97021 35.7497 9.46703 35.2028 10.0799 35.2028H32.9209C33.5338 35.2028 34.0306 35.7497 34.0306 36.4244V41.304C34.0306 41.9788 33.5338 42.5257 32.9209 42.5257H10.0799C9.46703 42.5257 8.97021 41.9788 8.97021 41.304V36.4244Z"
          fill="#FF7A00"
        />
        <path
          d="M14.6122 16.7199L19.5942 5.34781C20.3814 3.55073 22.6186 3.55073 23.4058 5.34781L28.3878 16.7199C28.9827 18.0778 30.5022 18.4914 31.5659 17.585L35.5939 14.1524C37.0951 12.8731 39.203 14.2713 38.9843 16.4013L36.7738 37.9299C36.6473 39.1614 35.737 40.0895 34.6556 40.0895H8.34441C7.26297 40.0895 6.35269 39.1614 6.22624 37.9299L4.01574 16.4013C3.79704 14.2713 5.90491 12.8731 7.4061 14.1524L11.4341 17.585C12.4978 18.4914 14.0173 18.0778 14.6122 16.7199Z"
          fill="url(#paint0_radial_56:1162)"
        />
        <path
          d="M19.8249 21.5509C20.6788 20.3086 22.3211 20.3086 23.175 21.5509L26.4802 26.3594C27.0905 27.2473 27.0905 28.4992 26.4802 29.3871L23.175 34.1956C22.3211 35.4379 20.6788 35.4379 19.8249 34.1956L16.5198 29.3871C15.9094 28.4992 15.9094 27.2473 16.5198 26.3594L19.8249 21.5509Z"
          fill="url(#paint1_radial_56:1162)"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_56:1162"
          x="0"
          y="0"
          width="43"
          height="46.5258"
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset />
          <feGaussianBlur stdDeviation="2" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 1 0 0 0 0 0.780392 0 0 0 0 0 0 0 0 0.3 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_56:1162"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_56:1162"
            result="shape"
          />
        </filter>
        <filter
          id="filter1_di_56:1162"
          x="13.3271"
          y="19.4945"
          width="16.3452"
          height="23.2393"
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dy="1" />
          <feGaussianBlur stdDeviation="2" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.68 0"
          />
          <feBlend
            mode="overlay"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_56:1162"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_56:1162"
            result="shape"
          />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dy="-1" />
          <feGaussianBlur stdDeviation="1" />
          <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 1 0 0 0 0 0.914286 0 0 0 0 0.55 0 0 0 1 0"
          />
          <feBlend
            mode="normal"
            in2="shape"
            result="effect2_innerShadow_56:1162"
          />
        </filter>
        <radialGradient
          id="paint0_radial_56:1162"
          cx="0"
          cy="0"
          r="1"
          gradientUnits="userSpaceOnUse"
          gradientTransform="translate(14.368 18.3136) rotate(60.1149) scale(25.1156 21.1081)"
        >
          <stop stopColor="#FFEB81" />
          <stop offset="0.682292" stopColor="#FFC839" />
        </radialGradient>
        <radialGradient
          id="paint1_radial_56:1162"
          cx="0"
          cy="0"
          r="1"
          gradientUnits="userSpaceOnUse"
          gradientTransform="translate(19.3187 25.0206) rotate(68.0922) scale(9.58279 9.3569)"
        >
          <stop stopColor="#FF7D16" />
          <stop offset="1" stopColor="#FF3E12" />
        </radialGradient>
      </defs>
    </svg>
  );
}

export default IconCoroa;
